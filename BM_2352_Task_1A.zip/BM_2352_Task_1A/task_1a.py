'''
*****************************************************************************************
*
*        		===============================================
*           		Berryminator (BM) Theme (eYRC 2021-22)
*        		===============================================
*
*  This script is to implement Task 1A of Berryminator(BM) Theme (eYRC 2021-22).
*  
*  This software is made available on an "AS IS WHERE IS BASIS".
*  Licensee/end user indemnifies and will keep e-Yantra indemnified from
*  any and all claim(s) that emanate from the use of the Software or 
*  breach of the terms of this agreement.
*
*****************************************************************************************
'''

# Team ID:			[ BM_2352 ]
# Author List:		[MANDAVA HEMANTH SIRISH KUMAR SAI,SUNKARA BHANU SREE SUPRIYA,PONUGUMATI BHANU SREE,THOTA RAVI TEJA ]
# Filename:			task_1a.py
# Functions:		detect_shapes
# 					[ Comma separated list of functions in this file ]


####################### IMPORT MODULES #######################
## You are not allowed to make any changes in this section. ##
## You have to implement this task with the three available ##
## modules for this task (numpy, opencv, os)                ##
##############################################################
import cv2
import numpy as np
import os
##############################################################

################# ADD UTILITY FUNCTIONS HERE #################





##############################################################

def detect_shapes(img):

	"""
	Purpose:
	---
	This function takes the image as an argument and returns a nested list
	containing details of colored (non-white) shapes in that image

	Input Arguments:
	---
	`img` :	[ numpy array ]
			numpy array of image returned by cv2 library

	Returns:
	---
	`detected_shapes` : [ list ]
			nested list containing details of colored (non-white) 
			shapes present in image
	
	Example call:
	---
	shapes = detect_shapes(img)
	"""    
	detected_shapes = []

	##############	ADD YOUR CODE HERE	##############
	imgGry = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
	blur = cv2.GaussianBlur(imgGry, (1, 1), cv2.BORDER_DEFAULT)
	equ = cv2.equalizeHist(blur)
	ret , thrash = cv2.threshold(equ, 240 , 255, cv2.CHAIN_APPROX_NONE)
	contours , hierarchy = cv2.findContours(thrash, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
	for contour in contours:
		approx = cv2.approxPolyDP(contour, 0.02 * cv2.arcLength(contour, True), True)
		cv2.drawContours(img, [approx], 0, (0, 0, 0), 2)
		x = approx.ravel()[0]
		y = approx.ravel()[1]-5
		M = cv2.moments(contour)
		if M['m00'] != 0:
			cx = int(M['m10']/M['m00'])
			cy = int(M['m01']/M['m00'])
		px0 = img[ cy, cx, 0]
		px1 = img[ cy, cx, 1]
		px2 = img[ cy, cx, 2]
		color = 'White'
		if(px0==255 and px1==0 and px2==0):
			color = 'Blue'
		elif(px0==0 and px1==0 and px2==255):
			color = 'Red'
		elif(px0==0 and px1==255 and px2==0):
			color='Green'
		elif(px0==0 and (px1==140 or px1==150) and px2==255):
			color="Orange"
		if len(approx) == 3:
			detected_shapes.append([color,'Triangle', (cx, cy)])
			cv2.circle(img, (cx, cy), 3, (0, 0, 255), -1)
			cv2.putText(img, "Triangle", (cx-20, cy-20), cv2.FONT_HERSHEY_COMPLEX, 0.5, (0, 0, 0))
		elif len(approx) == 4:
			x1, y1, w, h = cv2.boundingRect(approx)
			aspectRatio = float(w)/h
			#print(aspectRatio)
			if 0.95 <= aspectRatio <= 1.05:
				detected_shapes.append([color,'Square',(cx, cy)])
				cv2.circle(img, (cx, cy), 3, (0, 0, 255), -1)
				cv2.putText(img, "Square", (cx-20, cy-20), cv2.FONT_HERSHEY_COMPLEX, 0.5, (0, 0, 0))
			else:
				detected_shapes.append([color,'Rectangle',(cx, cy)])
				cv2.circle(img, (cx, cy), 3, (0, 0, 255), -1)
				cv2.putText(img, "Rectangle", (cx-20, cy-20), cv2.FONT_HERSHEY_COMPLEX, 0.5, (0, 0, 0))
		elif len(approx) == 5:
			detected_shapes.append([color,'Pentagon',(cx, cy)])
			cv2.circle(img, (cx, cy), 3, (0, 0, 255), -1)
			cv2.putText(img, "Pentagon", (cx-20, cy-20), cv2.FONT_HERSHEY_COMPLEX, 0.5, (0, 0, 0))
		else:
			detected_shapes.append([color,'Circle',(cx, cy)])
			cv2.circle(img, (cx, cy), 3, (0, 0, 255), -1)
			cv2.putText(img, "Circle", (cx-20, cy-20), cv2.FONT_HERSHEY_COMPLEX, 0.5, (0, 0, 0))

	 


	##################################################
	
	return detected_shapes

def get_labeled_image(img, detected_shapes):
	######### YOU ARE NOT ALLOWED TO MAKE CHANGES TO THIS FUNCTION #########
	"""
	Purpose:
	---
	This function takes the image and the detected shapes list as an argument
	and returns a labelled image

	Input Arguments:
	---
	`img` :	[ numpy array ]
			numpy array of image returned by cv2 library

	`detected_shapes` : [ list ]
			nested list containing details of colored (non-white) 
			shapes present in image

	Returns:
	---
	`img` :	[ numpy array ]
			labelled image
	
	Example call:
	---
	img = get_labeled_image(img, detected_shapes)
	"""
	######### YOU ARE NOT ALLOWED TO MAKE CHANGES TO THIS FUNCTION #########    

	for detected in detected_shapes:
		colour = detected[0]
		shape = detected[1]
		coordinates = detected[2]
		cv2.putText(img, str((colour, shape)),coordinates, cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,0,0), 2)
	return img

if __name__ == '__main__':
	
	# path directory of images in 'test_images' folder
	img_dir_path = 'test_images/'

	# path to 'test_image_1.png' image file
	file_num = 1
	img_file_path = img_dir_path + 'test_image_' + str(file_num) + '.png'
	
	# read image using opencv
	img = cv2.imread(img_file_path)
	
	print('\n============================================')
	print('\nFor test_image_' + str(file_num) + '.png')
	
	# detect shape properties from image
	detected_shapes = detect_shapes(img)
	print(detected_shapes)
	
	# display image with labeled shapes
	img = get_labeled_image(img, detected_shapes)
	cv2.imshow("labeled_image", img)
	cv2.waitKey(2000)
	cv2.destroyAllWindows()
	
	choice = input('\nDo you want to run your script on all test images ? => "y" or "n": ')
	
	if choice == 'y':

		for file_num in range(1, 15):
			
			# path to test image file
			img_file_path = img_dir_path + 'test_image_' + str(file_num) + '.png'
			
			# read image using opencv
			img = cv2.imread(img_file_path)
	
			print('\n============================================')
			print('\nFor test_image_' + str(file_num) + '.png')
			
			# detect shape properties from image
			detected_shapes = detect_shapes(img)
			print(detected_shapes)
			
			# display image with labeled shapes
			img = get_labeled_image(img, detected_shapes)
			cv2.imshow("labeled_image", img)
			cv2.waitKey(2000)
			cv2.destroyAllWindows()


